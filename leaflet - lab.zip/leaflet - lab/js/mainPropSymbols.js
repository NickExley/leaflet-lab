//create function to make the proportional symbols of a certain color, fill, opacity, etc
function createPropSymbols(data, map){
	var geojsonMarkerOptions = {
		radius: 8,
		fillColor: "#1e90ff",
		color: "#000",
		weight: 1,
		opacity: 1,
		fillOpacity: 0.8
	};
	
	//assigns the specific field of data to be used for the proportional symbols 
	var attribute  = "2016_1";
	
	
	//adjusts the symbols for each data point to reflect its value using the calcPropRadius function results
	L.geoJson(data, {
		pointToLayer: function (feature, latlng) {
			
			var attValue = Number(feature.properties[attribute]);
			console.log(feature.properties);
			geojsonMarkerOptions.radius = calcPropRadius(attValue);
			
			return L.circleMarker(latlng, geojsonMarkerOptions);		
		}
	}).addTo(map);

};

//function to retrieve the data and place it on the map
function getData(map){
    //load the data
    $.ajax("data/ElectionTurnout.geojson", {
        dataType: "json",
        success: function(response){  
			createPropSymbols(response, map);
		}
      }
	)
};

//calculate the radius of each proportional symbol
function calcPropRadius(attValue) {
    //scale factor to adjust symbol size evenly
    var scaleFactor = 15;
    //area based on attribute value and scale factor
    var area = attValue * scaleFactor;
    //radius calculated based on area
    var radius = Math.sqrt(area/Math.PI);

    return radius;
};

//function to create the Leaflet map
function createMap(){
    //create the map
    var map = L.map('mapid', {
        center: [40, -95],
        zoom: 4
    });

    //add OSM base tilelayer
    L.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>'
    }).addTo(map);

    //call getData function
    getData(map);
};

//creates the entire map once the page is loaded
$(document).ready(createMap);